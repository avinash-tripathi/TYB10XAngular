import { MenuItem } from './menu.model';

export const MENU: MenuItem[] = [
    {
        id: 1,
        label: 'MENUITEMS.MENU.TEXT',
        isTitle: true
    },
    {
        id: 2,
        label: 'MENUITEMS.DASHBOARDS.TEXT',
        icon: 'bx-home-circle',
        badge: {
            variant: 'info',
            text: 'MENUITEMS.DASHBOARDS.BADGE',
        },
        subItems: [
            {
                id: 3,
                label: 'MENUITEMS.DASHBOARDS.LIST.DEFAULT',
                link: '/dashboard',
                parentId: 2
            },

        ]
    },
    {
        id: 7,
        isLayout: true
    },
    {
        id: 8,
        label: 'MENUITEMS.APPS.TEXT',
        isTitle: true
    },
    {
        id: 500,
        label: 'FRANCHISE ONBOARD',
        icon: 'bx-store',
        subItems: [
            {
                id: 501,
                label: 'ONBOARD',
                link: 'onboard/franchise',
                parentId: 500
            },
            {
                id: 502,
                label: 'UPLOAD FILE',
                link: 'onboard/upload',
                parentId: 500
            }
        ]
    },
    {
        id: 600,
        label: 'CATALOG',
        icon: 'bx-store',
        subItems: [
            {
                id: 601,
                label: 'PRODUCT',
                link: 'catalog/product',
                parentId: 600
            },
            {
                id: 602,
                label: 'FRANCHISE PRODUCTS',
                link: 'catalog/franchisetoproduct',
                parentId: 600
            }
        ]
    },
    

    {
        id: 700,
        label: 'SETTING',
        icon: 'bx-store',
        subItems: [
            {
                id: 701,
                label: 'ROLE',
                link: '/setting/role',
                parentId: 700
            }
        ]
    },





];

