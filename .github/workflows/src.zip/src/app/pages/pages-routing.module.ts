import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultComponent } from './dashboards/default/default.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard' },
 
  { path: 'dashboard', component: DefaultComponent },
 
  { path: 'dashboards', loadChildren: () => import('./dashboards/dashboards.module').then(m => m.DashboardsModule) },
  { path: 'ecommerce', loadChildren: () => import('./ecommerce/ecommerce.module').then(m => m.EcommerceModule) },
 { path: 'projects', loadChildren: () => import('./projects/projects.module').then(m => m.ProjectsModule) },
 // { path: 'pages', loadChildren: () => import('./utility/utility.module').then(m => m.UtilityModule) },
 // { path: 'ui', loadChildren: () => import('./ui/ui.module').then(m => m.UiModule) },
 // { path: 'form', loadChildren: () => import('./form/form.module').then(m => m.FormModule) },
 { path: 'onboard', loadChildren: () => import('./onboard/onboard.module').then(m => m.OnboardModule) },
 { path: 'catalog', loadChildren: () => import('./catalog/catalog.module').then(m => m.CatalogModule) }

  
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
