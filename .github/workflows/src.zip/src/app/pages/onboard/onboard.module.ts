import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbNavModule, NgbDropdownModule, NgbPaginationModule, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { WidgetModule } from '../../shared/widget/widget.module';
import { DropzoneModule } from 'ngx-dropzone-wrapper';
import { CommonModule } from '@angular/common';
import { OnboardRoutingModule } from './onboard-routing.module';
import { FranchiseonboardComponent } from './franchiseonboard/franchiseonboard.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { UIModule } from '../../shared/ui/ui.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { FileuploadComponent } from './fileupload/fileupload.component';

@NgModule({
  declarations: [
    
    FranchiseonboardComponent,
         FileuploadComponent
  ],
  imports: [
    CommonModule,
    UIModule,
    DropzoneModule,
    WidgetModule,
    FormsModule, ReactiveFormsModule,
    OnboardRoutingModule,
    NgbNavModule, NgbDropdownModule, NgbPaginationModule, NgbModalModule,Ng2SearchPipeModule,
    NgSelectModule
  ]
})
export class OnboardModule { }
