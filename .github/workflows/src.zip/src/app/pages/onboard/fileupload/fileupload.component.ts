import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.scss']
})
export class FileuploadComponent implements OnInit {
  // bread crumb items
  breadCrumbItems: Array<{}>;
  formData: FormGroup;
  submitted = false;
  currentpage: number;
 
  constructor(private modalService: NgbModal, private formBuilder: FormBuilder,
    ) { }

  ngOnInit(): void {
    this.breadCrumbItems = [{ label: 'UPLOAD DOCUMENT' }, { label: 'ZIP FILES', active: true }];
    this.formData = this.formBuilder.group({
      customername: ['', [Validators.required]],
      phone: ['', [Validators.required]],
    });

  }
  get form() {
    return this.formData.controls;
  }

  onUploadError(args: any) {
    console.log('onUploadError:', args);
  }
  imagesizeexceed :string='';
  isSizeExceed:  boolean=false;

  onUploadSuccess(args: any) {
    
     var val = args[0].dataURL.toString();
     var _imageSize = args[0].size;
     var _readytoupload = true;
     if (_imageSize>500000){ 
       this.imagesizeexceed = " Your image size is " + (_imageSize/1024) + "KB. *Note: Image size must not exceed above 500 KB.";
       this.isSizeExceed=true;
       _readytoupload = false;
     }else
     {
      this.isSizeExceed=false;
      this.imagesizeexceed ='';

     }

    var base64Index = val.indexOf(';base64,') + ';base64,'.length;
    var base64 = val.substring(base64Index);
    //let obj = { 'base64image': base64 ,'productcode':this.productEditData.productcode}
    
    // if (_readytoupload){
    //    this.productService.addImage(obj).subscribe(res=>{
    //      console.log(res);
    //    })

    // }
     
}
saveFranchise(){}

}
