import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FranchisetoproductComponent } from './franchisetoproduct/franchisetoproduct.component';
import { ProductComponent } from './product/product.component';

const routes: Routes = [
  {
      path: 'catalog/product',
      component: ProductComponent
  },
  {
    path: 'catalog/franchisetoproduct',
    component: FranchisetoproductComponent
},
  
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CatalogRoutingModule { }
