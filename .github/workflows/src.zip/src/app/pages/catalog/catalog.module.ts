import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbNavModule, NgbDropdownModule, NgbPaginationModule, NgbModalModule } 
from '@ng-bootstrap/ng-bootstrap';

import { Ng2SearchPipeModule } from 'ng2-search-filter';

import { NgSelectModule } from '@ng-select/ng-select';
import { CatalogRoutingModule } from './catalog-routing.module';
import { ProductComponent } from './product/product.component';
import { WidgetModule } from 'src/app/shared/widget/widget.module';
import { UIModule } from 'src/app/shared/ui/ui.module';
import { FranchisetoproductComponent } from './franchisetoproduct/franchisetoproduct.component';

@NgModule({
  declarations: [
    ProductComponent,
    FranchisetoproductComponent
  ],
  imports: [
   
   CommonModule,
    UIModule,
    WidgetModule,
    FormsModule, ReactiveFormsModule,
    
    NgbNavModule, NgbDropdownModule, NgbPaginationModule, NgbModalModule,Ng2SearchPipeModule,
    NgSelectModule,
    CatalogRoutingModule
  ]
})
export class CatalogModule { }
