export interface Shops {
    poducts: number;
    balance: string;
    title: string;
    color: string;
}
