import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

import { Franchise } from 'src/app/core/models/franchise.model';
import { FranchiseToProduct } from '../models/franchisetoproduct';


@Injectable({
  providedIn: 'root'
})
export class FranchiseService {

  constructor(private http: HttpClient) {
  }


  getFranchises() {
    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,PUT,GET,OPTIONS')
        .append('Accept', 'application/json');

      return this.http.get<Franchise[]>(`${environment.baseUrl}Franchise`
        , { headers: headers });

    }
    catch (error) {
      console.error('Here is the error message', error);
    }

  }
  getProductMapWithFranchiseCategory( franchiseCategory: string) {
    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,PUT,GET,OPTIONS')
        .append('Accept', 'application/json');

      return this.http.get<Franchise[]>(`${environment.baseUrl}Franchise/GetProductMapwithFranchiseCategory?franchisecategory=`+franchiseCategory
        , { headers: headers });

    }
    catch (error) {
      console.error('Here is the error message', error);
    }

  }
  readProductMapWithFranchiseCategory() {
    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,PUT,GET,OPTIONS')
        .append('Accept', 'application/json');

      return this.http.get<FranchiseToProduct[]>(`${environment.baseUrl}Franchise/readFranchiseCategoryProducts`
        , { headers: headers });

    }
    catch (error) {
      console.error('Here is the error message', error);
    }

  }


  addFranchise(data: Franchise): Observable<any> {

    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,GET,OPTIONS')
        .append('Accept', 'application/json');

      const body = JSON.stringify(data);
      return this.http.post<any>(`${environment.baseUrl}Franchise`, body,
        { headers: headers })
        ;
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
  }

  editFranchise(data: Franchise): Observable<any> {

    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'PUT,POST,GET,OPTIONS')
        .append('Accept', 'application/json');

      const body = JSON.stringify(data);
      return this.http.put<any>(`${environment.baseUrl}Franchise`, body,
        { headers: headers })
        ;
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
  }


  deleteFranchise(data: Franchise): Observable<any> {

    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,GET,OPTIONS')
        .append('Accept', 'application/json');
      const body = JSON.stringify(data);
      const options = {
        headers: headers,
        body: body
      };
      return this.http.delete<any>(`${environment.baseUrl}Franchise`
        , options
      );
      ;
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
  }


}
