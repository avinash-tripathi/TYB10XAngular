import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';
import { Product } from '../models/product';
import { Franchise } from 'src/app/core/models/franchise.model';
import { FranchiseToProduct } from '../models/franchisetoproduct';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { 
  }
  

  getProducts(){
    try{
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,PUT,GET,OPTIONS')
        .append('Accept', 'application/json');
  
      return this.http.get<Product[]>(`${environment.baseUrl}Product`
      ,{ headers: headers });
  
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
  
  }
  getFranchisetoProducts(){
    try{
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,PUT,GET,OPTIONS')
        .append('Accept', 'application/json');
  
      return this.http.get<FranchiseToProduct[]>(`${environment.baseUrl}Product`
      ,{ headers: headers });
  
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
  
  }

  
  getImage(){
    try{
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,PUT,GET,OPTIONS')
        .append('Accept', 'application/json');
  
      return this.http.get<any>(`${environment.baseUrl}Product/GetBase64String`
      ,{ headers: headers });
  
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
  
  }

  addImage(obj: any): Observable<any> {

    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,GET,OPTIONS')
        .append('Accept', 'application/json');
        
        const body = JSON.stringify(obj);
      return this.http.put<any>(`${environment.baseUrl}Product/UploadImage`,body,
       { headers: headers }) 
      ;
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
}


   addProduct(data: Product): Observable<any> {

    try {
      const headers = new HttpHeaders()
        .set('content-type', 'application/json')
        .append('Access-Control-Allow-Origin', '*')
        .append('Access-Control-Allow-Headers', '*')
        .append('Access-Control-Allow-Methods', 'POST,GET,OPTIONS')
        .append('Accept', 'application/json');
        
        const body = JSON.stringify(data);
      return this.http.post<any>(`${environment.baseUrl}Product`,body,
       { headers: headers }) 
      ;
    }
    catch (error) {
      console.error('Here is the error message', error);
    }
}
addFranchiseToProduct(data: FranchiseToProduct): Observable<any> {

  try {
    const headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .append('Access-Control-Allow-Origin', '*')
      .append('Access-Control-Allow-Headers', '*')
      .append('Access-Control-Allow-Methods', 'POST,GET,OPTIONS')
      .append('Accept', 'application/json');
      
      const body = JSON.stringify(data);
    return this.http.post<any>(`${environment.baseUrl}Franchise/MapProductWithCategory`,body,
     { headers: headers }) 
    ;
  }
  catch (error) {
    console.error('Here is the error message', error);
  }
}
editProduct(data: Product): Observable<any> {

  try {
    const headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .append('Access-Control-Allow-Origin', '*')
      .append('Access-Control-Allow-Headers', '*')
      .append('Access-Control-Allow-Methods', 'PUT,POST,GET,OPTIONS')
      .append('Accept', 'application/json');
      
      const body = JSON.stringify(data);
    return this.http.put<any>(`${environment.baseUrl}Product`,body,
     { headers: headers }) 
    ;
  }
  catch (error) {
    console.error('Here is the error message', error);
  }
}


deleteProduct(data: Product): Observable<any> {

  try {
    const headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .append('Access-Control-Allow-Origin', '*')
      .append('Access-Control-Allow-Headers', '*')
      .append('Access-Control-Allow-Methods', 'POST,GET,OPTIONS')
      .append('Accept', 'application/json');
      const body = JSON.stringify(data);
      const options = {
        headers: headers,
        body: body
      };
      return this.http.delete<any>(`${environment.baseUrl}Product`
      ,options
    );
    ;
  }
  catch (error) {
    console.error('Here is the error message', error);
  }
}
deleteFranchiseToProduct(data: FranchiseToProduct): Observable<any> {

  try {
    const headers = new HttpHeaders()
      .set('content-type', 'application/json')
      .append('Access-Control-Allow-Origin', '*')
      .append('Access-Control-Allow-Headers', '*')
      .append('Access-Control-Allow-Methods', 'POST,GET,OPTIONS')
      .append('Accept', 'application/json');
      const body = JSON.stringify(data);
      const options = {
        headers: headers,
        body: body
      };
      return this.http.delete<any>(`${environment.baseUrl}Product`
      ,options
    );
    ;
  }
  catch (error) {
    console.error('Here is the error message', error);
  }
}

}
