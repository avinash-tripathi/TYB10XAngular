export class Franchise {
    franchisecode: string;
    franchisename:string;
    franchisecategory:string;
    phone: string;
    email: string;
    address: string;
    city: string;
    state: string;
    bankname: string;
    bankbranch: string;
    accountnumber: string;
    ifsccode: string;
    accountholdername: string;
    bankaddress: string;
    punchedby: string;
    introducercode: string;
    
}
