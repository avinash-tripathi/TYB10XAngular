
import { ProductOnly } from "./productonly";

export class FranchiseToProduct {
    
    franchisecategory: string;
    
    products:ProductOnly[];

}
