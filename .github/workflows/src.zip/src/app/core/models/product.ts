export class Product {
    productid: number;
    productcode: string;
    productname: string;
    costtocustomer: number;
    costtofranchise: string;
    punchedby:string;
    status:boolean;

}
