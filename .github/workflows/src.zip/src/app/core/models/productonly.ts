export class ProductOnly {
    
    productcode: string;
    productname: string;
    status:boolean;

}
